r = eval(input())
pi = 3.14159
print(2 * pi * r)
print(pi * r**2)
