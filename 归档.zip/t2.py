n = input()
a=[]
a=n.split()
a.pop(0)
a.reverse()
for i in a:
    print(i,end=" ")
