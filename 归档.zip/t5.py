a=[]
for i in range(10):
    a.append(input())
a.reverse()
for i in a:
    print(i,end=" ")